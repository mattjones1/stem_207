STEM 207 Brand Kit · powered by STEM Coliseum and Learning Center · October 2026

Start with STEM207_Brand_Guide.pdf.

logos/stem-207/      STEM 207 logo (SVG + 2000 px PNG), reverse logo for dark backgrounds, and the mark (icon)
logos/lockups/       "STEM 207 powered by STEM Coliseum", horizontal and stacked, on white
logos/stem-coliseum/ The nine approved STEM Coliseum logo versions, as supplied by STEM Coliseum
colors/              The palette as CSS and plain text

Mission (exact wording): Keep the humanity in technology.
STEM 207, LLC is a program offered exclusively through STEM Coliseum and Learning Center.
STEM Coliseum: https://stem-coliseum.odoo.com/
